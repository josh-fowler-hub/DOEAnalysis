# Pairwise Design of Experiments (DOE): Theory, Algorithm, and Math

## 1. Introduction
Design of Experiments (DOE) explores factor effects systematically. A full factorial design tests every combination:

$$N_{\text{full}} = \prod_{i=1}^k L_i$$

For our case:

$$k = 12, \quad L = [5,5,5,5,4,2,2,3,2,5,7,9]$$

$$N_{\text{full}} = 18{,}900{,}000 \text{ runs}$$

![Full vs Pairwise](diagrams/full_vs_pairwise.png)

## 2. Pairwise Coverage Concept
Instead of all combinations, pairwise DOE ensures every *pair* of factor levels appears at least once.

![Pairwise Concept](diagrams/pairwise_concept.png)

## 3. Mathematical Basis
For each pair of factors $(F_i, F_j)$:

$$\text{Pairs} = L_i \times L_j$$

Total pairs:

$$\sum_{i<j} L_i L_j$$

## 4. Algorithm Flow
Greedy approach:

![Algorithm Flowchart](diagrams/algorithm_flowchart.png)

Steps:
1. Define factors & levels.
2. Generate all pairs.
3. Initialize uncovered pairs.
4. Loop: sample candidates, select best coverage.
5. Repeat until all pairs covered.

## 5. Result
Full factorial: $$\approx 18.9 \text{ million runs}$$
Pairwise DOE: $$\approx 73 \text{ runs}$$

Reduction:

$$\text{Reduction} = \frac{18{,}900{,}000}{73} \approx 258{,}904$$

## 6. Practical Notes
- Covers all two-factor interactions.
- Does not guarantee higher-order coverage.
- Use constraints to filter infeasible combos.

## 7. References
- Kuhn et al. (2004), *Software fault interactions and pairwise testing*.
- Montgomery (2017), *Design and Analysis of Experiments*.
